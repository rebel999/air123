package com.cg.ars.exception;

public class UserException extends Exception
{
	private static final long serialVersionUID = 1026652107861467516L;

	public UserException(String message)
	{
		super(message);
	}
}
