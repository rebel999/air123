package com.cg.ars.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="USERS")
public class User 
{
	@Id
	@Column(name="USERNAME")
	private String username;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="ROLE")
	private String role;
	
	@Column(name="MOBILE_NO")
	private String mobileNo;
	
	@Transient
	public static final String USER = "User";
	
	@Transient
	public static final String ADMIN = "Admin";
	
	@Transient
	public static final String EXECUTIVE = "Executive";

	/**
	 * Default No-Argument Constructor
	 */
	public User() {
		super();
	}

	/*
	 * Getters and Setters
	 */
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * Override toString() method
	 * @return String representing an instance of this class
	 */
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", role=" + role + ", mobileNo=" + mobileNo
				+ "]";
	}
	
	public static String[] getRoles()
	{
		return new String[] {USER, ADMIN, EXECUTIVE};
	}
}
