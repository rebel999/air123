# AirlinesReservationSystem

Mini Project in Java using JPA with Hibernate, and MVC.
<!--
![Screenshot 1](./screenshots/screenshot1.png)
<br/><br/><br/><br/>
-->
Project Members
---------------

![Pratanu Mandal<br>(Team Leader)](./images/pratanu.jpg)|![Bhavin Mohan](./images/bhavin.jpg)|![Gurveen Kaur](./images/gurveen.jpg)|
:------------------------------------------------------:|:----------------------------------:|:-----------------------------------:|
Pratanu Mandal<br>(Team Leader)                         |Bhavin Mohan                        |Gurveen Kaur                         |
![Sajal Bain](./images/sajal.jpg)|![Sanjay Deb](./images/sanjay.jpg)|![Subhojita Saha](./images/subhojita.jpg)|
Sajal Bain                       |Sanjay Deb                        |Subhojita Saha                           |
