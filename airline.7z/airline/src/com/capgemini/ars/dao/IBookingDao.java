package com.capgemini.ars.dao;

public interface IBookingDao {

}
