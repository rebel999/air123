package com.capgemini.ars.dao;

public interface IUserDao {

}
