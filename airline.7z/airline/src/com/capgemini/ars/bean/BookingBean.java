package com.capgemini.ars.bean;

public class BookingBean {

}
