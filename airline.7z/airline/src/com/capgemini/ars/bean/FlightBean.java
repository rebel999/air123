package com.capgemini.ars.bean;

import java.time.LocalDate;
import java.time.LocalTime;

public class FlightBean {
	
	private Integer flightNo;
	private String airLine;
	private String depCity;
	private String arrCity;
	private LocalDate depDate;
	private LocalDate arrDate;
	private LocalTime depTime;
	private LocalTime arrTime;
	private Integer firstSeats;
	private Integer bussSeats;
	private Double firstSeatsFare;
	private Double bussSeatsFare;
	
	
	public FlightBean() {
		super();
	}


	public FlightBean(Integer flightNo, String airLine, String depCity,
			String arrCity, LocalDate depDate, LocalDate arrDate,
			LocalTime depTime, LocalTime arrTime, Integer firstSeats,
			Integer bussSeats, Double firstSeatsFare, Double bussSeatsFare) {
		super();
		this.flightNo = flightNo;
		this.airLine = airLine;
		this.depCity = depCity;
		this.arrCity = arrCity;
		this.depDate = depDate;
		this.arrDate = arrDate;
		this.depTime = depTime;
		this.arrTime = arrTime;
		this.firstSeats = firstSeats;
		this.bussSeats = bussSeats;
		this.firstSeatsFare = firstSeatsFare;
		this.bussSeatsFare = bussSeatsFare;
	}


	public Integer getFlightNo() {
		return flightNo;
	}


	public void setFlightNo(Integer flightNo) {
		this.flightNo = flightNo;
	}


	public String getAirLine() {
		return airLine;
	}


	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}


	public String getDepCity() {
		return depCity;
	}


	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}


	public String getArrCity() {
		return arrCity;
	}


	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}


	public LocalDate getDepDate() {
		return depDate;
	}


	public void setDepDate(LocalDate depDate) {
		this.depDate = depDate;
	}


	public LocalDate getArrDate() {
		return arrDate;
	}


	public void setArrDate(LocalDate arrDate) {
		this.arrDate = arrDate;
	}


	public LocalTime getDepTime() {
		return depTime;
	}


	public void setDepTime(LocalTime depTime) {
		this.depTime = depTime;
	}


	public LocalTime getArrTime() {
		return arrTime;
	}


	public void setArrTime(LocalTime arrTime) {
		this.arrTime = arrTime;
	}


	public Integer getFirstSeats() {
		return firstSeats;
	}


	public void setFirstSeats(Integer firstSeats) {
		this.firstSeats = firstSeats;
	}


	public Integer getBussSeats() {
		return bussSeats;
	}


	public void setBussSeats(Integer bussSeats) {
		this.bussSeats = bussSeats;
	}


	public Double getFirstSeatsFare() {
		return firstSeatsFare;
	}


	public void setFirstSeatsFare(Double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}


	public Double getBussSeatsFare() {
		return bussSeatsFare;
	}


	public void setBussSeatsFare(Double bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}


	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", airLine=" + airLine
				+ ", depCity=" + depCity + ", arrCity=" + arrCity
				+ ", depDate=" + depDate + ", arrDate=" + arrDate
				+ ", depTime=" + depTime + ", arrTime=" + arrTime
				+ ", firstSeats=" + firstSeats + ", bussSeats=" + bussSeats
				+ ", firstSeatsFare=" + firstSeatsFare + ", bussSeatsFare="
				+ bussSeatsFare + "]";
	}
	
	
	

}
