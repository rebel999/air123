package com.capgemini.ars.bean;

public class AirportBean {
	private String airportName;
	private String abbrevation;
	private String location;
	
	
	public AirportBean() {
		super();
	}

	public AirportBean(String airportName, String abbrevation, String location) {
		super();
		this.airportName = airportName;
		this.abbrevation = abbrevation;
		this.location = location;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getAbbrevation() {
		return abbrevation;
	}

	public void setAbbrevation(String abbrevation) {
		this.abbrevation = abbrevation;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "AirportBean [airportName=" + airportName + ", abbrevation="
				+ abbrevation + ", location=" + location + "]";
	}
	

}
